// A shim to not really expose the Box object during explanation
// @TODO(mduvall): Before release this needs to be fixed.
var Application = Box.Application;
