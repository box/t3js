Application.init({
  debug: true
});
