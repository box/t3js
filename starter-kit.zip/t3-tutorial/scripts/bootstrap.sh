#!/bin/sh

ruby -e "$(curl -fsSL https://raw.github.com/Homebrew/homebrew/go/install)"
brew install node
sudo npm install -g yo
npm install git+ssh://git@gitenterprise.inside-box.net:Box/generator-t3.git

