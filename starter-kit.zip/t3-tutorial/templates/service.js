/**
 * @fileoverview Description of file
 * @author bclinton
 */

/*global Box*/

/**
 * Description of service.
 */
Application.addService('service', function(application) {

	'use strict';

	//--------------------------------------------------------------------------
	// Private
	//--------------------------------------------------------------------------

	/**
	 * Description of function.
	 * @param {type} name Description
	 * @returns {type} Description
	 * @private
	 */
	function privateFunction(name) {

	}

	//--------------------------------------------------------------------------
	// Public
	//--------------------------------------------------------------------------

	return {

		/**
		 * Description of method.
		 * @param {type} name Description
		 * @returns {type} Description
		 */
		method: function(name) {

		}
	};

});
