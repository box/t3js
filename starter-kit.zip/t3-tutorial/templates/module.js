/**
 * @fileoverview Description of file
 * @author bclinton
 */

/*global Box*/

/**
 * Description of module.
 */
Application.addModule('module', function(context) {

	'use strict';

	//--------------------------------------------------------------------------
	// Private
	//--------------------------------------------------------------------------

	// private functions and variables go here

	//--------------------------------------------------------------------------
	// Public
	//--------------------------------------------------------------------------

	return {

		/**
		 * The messages that this modules listens for.
		 * @type String[]
		 */
		messages: [],

		/**
		 * Initializes the module.
		 * @returns {void}
		 */
		init: function() {

			// code to be run when module is started

		},

		/**
		 * Destroys the module.
		 * @returns {void}
		 */
		destroy: function() {

			// code to be run when module is stopped

		},

		/**
		 * Handles all click events for the module.
		 * @param {Event} event A DOM-normalized event object.
		 * @param {HTMLElement} element The nearest HTML element with a data-type
		 *      attribute specified or null if there is none.
		 * @param {string} elementType The value of data-type for the nearest
		 *      element with that attribute specified or null if there is none.
		 * @returns {void}
		 */
		onclick: function(event, element, elementType) {

			// code to be run when a click occurs

		},


		/**
		 * Handles all messages received for the module.
		 * @param {string} name The name of the message received.
		 * @param {*} [data] Additional data sent along with the message.
		 * @returns {void}
		 */
		onmessage: function(name, data) {

			// code to be run when a message is received

		}
	};

});
